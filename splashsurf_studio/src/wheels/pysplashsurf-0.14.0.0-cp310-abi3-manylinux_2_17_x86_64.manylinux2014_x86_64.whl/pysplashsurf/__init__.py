from .pysplashsurf import *
from . import bgeo
import sys


def run_pysplashsurf():
    run_splashsurf(sys.argv)
