```{include} ../../../README.md
```

```{toctree}
:caption: Table of Contents
api
functions
classes
```